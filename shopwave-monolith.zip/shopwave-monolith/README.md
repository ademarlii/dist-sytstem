# ShopWave — Monolith

Dağıtık Sistemler lab dersleri için hazırlanmış **başlangıç noktası**.  
E-ticaret temalı, tam çalışan bir monolitik uygulama.

## Stack

| Katman    | Teknoloji |
|-----------|-----------|
| Backend   | Spring Boot 3.2, Java 21, JPA, Flyway |
| Inventory | Spring Boot 3.2, Java 21, JPA, Flyway |
| Veritabanı| PostgreSQL 15 (backend DB + inventory DB) |
| Frontend  | React 18, TypeScript, Vite, Tailwind CSS |
| Infra     | Docker Compose |

## Başlatmak

```bash
docker compose up --build
```

| Servis        | URL                                     |
|---------------|-----------------------------------------|
| Frontend      | http://localhost:3000                   |
| Backend API   | http://localhost:8080/api/v1/products   |
| Inventory API | http://localhost:18081/api/v1/inventory/products/1 |
| Health        | http://localhost:8080/health            |
| Actuator      | http://localhost:8080/actuator/health   |
| DB            | localhost:5432 / shopwave               |
| Inventory DB  | localhost:15433 / shopwave_inventory    |

## API Özeti

```bash
# Ürünler
GET  /api/v1/products
GET  /api/v1/products/{id}
POST /api/v1/products
PATCH /api/v1/products/{id}/price

# Siparişler
POST /api/v1/orders              # sipariş ver
POST /api/v1/orders/{id}/confirm
POST /api/v1/orders/{id}/ship
POST /api/v1/orders/{id}/deliver
POST /api/v1/orders/{id}/cancel
GET  /api/v1/orders/customer/{customerId}

# Stok
POST /api/v1/inventory/products/{id}/add
GET  /api/v1/inventory/low-stock

# Audit
GET  /api/v1/audit

# Müşteriler
GET  /api/v1/customers
```

---

## Mimari Notlar (Lab Başlangıcı)

Bu sistemde şu anda:

- Backend ve inventory-service ayrı process olarak çalışır
- Backend ve inventory-service ayrı PostgreSQL veritabanları kullanır
- Sipariş + stok rezervasyonu artık **tek transaction** içinde değildir
- Backend ile inventory arasında HTTP çağrısı olduğu için ağ belirsizliği vardır
- Inventory HTTP çağrılarında timeout ve sınırlı retry vardır
- Sipariş başarısız olursa ayrılmış stok saga compensation ile geri bırakılır
- Backend DB'de `outbox_events` tablosu vardır; order ve compensation eventleri önce buraya yazılır
- Tüm audit logları asıl işlemle **atomik** yazılır

Bu özellikler sistem dağıtıklaştıkça **birer birer ortadan kalkacak**.

---

## Lab Yol Haritası

### LAB-1 — Monolith Sağlamlaştırma
- [ ] Structured logging (JSON formatı)
- [ ] Her isteğe `X-Correlation-ID` eklenmesi
- [ ] MDC ile tüm log satırlarında correlation-id görüntülenmesi
- [ ] p95 / p99 gecikme ölçümü (Micrometer)

### LAB-2 — Kaos & Gecikme Enjeksiyonu
- [ ] `OrderService.placeOrder()` içine yapay gecikme eklenmesi
- [ ] Jitter ile gecikme varyasyonu
- [ ] Race condition gözlemlenmesi (paralel istek atılması)

### LAB-3 — Kod İçi Sınırların Netleştirilmesi
- [ ] Inventory, Order, Catalog, Audit modüllerinin paket bazında ayrılması
- [ ] Veri sahipliğinin belgelenmesi
- [ ] Servis sınırlarının çizilmesi

### LAB-4 — Timeout & Deadline
- [x] `InventoryService.reserve()` için maksimum süre sınırı
- [ ] `OrderService.placeOrder()` için toplam deadline
- [x] Timeout aşımında anlamlı hata yanıtı

### LAB-5 — Idempotency
- [ ] `POST /api/v1/orders` için `X-Idempotency-Key` desteği
- [ ] Aynı key ile ikinci isteğin ilk sonucu dönmesi
- [ ] Key TTL yönetimi

### LAB-6 — Servis Ayrımı (Gerçek Dağıtıklık)
- [x] `InventoryService` → ayrı Spring Boot uygulaması
- [x] Ayrı PostgreSQL DB
- [x] HTTP client entegrasyonu (`RestClient` veya `WebClient`)
- [x] Ağ hatası ve timeout senaryolarının gözlemlenmesi
- [x] Partial failure: sipariş kaydedildi ama stok rezerve edilemedi

### LAB-7 — Resilience
- [x] Retry
- [ ] Circuit Breaker (Resilience4j)
- [ ] Fallback stratejisi
- [ ] Bulkhead izolasyonu

### LAB-8 — Saga Pattern
- [ ] Choreography-based saga (event'lerle)
- [x] Compensation: başarısız order akışında stok geri bırakılır
- [x] Outbox Pattern: order ve compensation event'leri güvenli iletimi

### LAB-9 — Gözlemlenebilirlik
- [ ] Distributed tracing (Micrometer Tracing + Zipkin)
- [ ] Prometheus metrikleri
- [ ] Grafana dashboard
- [ ] Golden signals: latency, traffic, errors, saturation
