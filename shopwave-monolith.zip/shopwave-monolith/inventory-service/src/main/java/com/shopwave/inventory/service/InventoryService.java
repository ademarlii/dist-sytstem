package com.shopwave.inventory.service;

import com.shopwave.inventory.domain.Inventory;
import com.shopwave.inventory.dto.InventoryDto;
import com.shopwave.inventory.exception.InsufficientStockException;
import com.shopwave.inventory.exception.NotFoundException;
import com.shopwave.inventory.repository.InventoryRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * InventoryService - stok rezervasyon ve guncelleme islemleri.
 *
 * Bu servis artik monolith disinda ayri process ve ayri veritabani olarak calisir.
 * OrderService bu sinifa direkt metot cagrisi yapmaz; HTTP uzerinden gelir.
 *
 * LAB NOTU (Servis Ayrimi - Lab 3):
 *   DB lock yalnizca inventory-service veritabani icinde stok satirini korur.
 *   Order DB commit'i ile stok rezervasyonu artik atomik degildir.
 *   Ag kesilmesi, timeout ve partial failure senaryolari burada gozlemlenir.
 *   Cozum yollari: Saga (choreography / orchestration), 2PC, Outbox.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class InventoryService {

    private final InventoryRepository inventoryRepository;
    private final ChaosDelayService chaosDelayService;

    @Transactional(readOnly = true)
    public InventoryDto getByProductId(Long productId) {
        return inventoryRepository.findByProductId(productId)
                .map(this::toDto)
                .orElseThrow(() -> new NotFoundException("Inventory not found for product: " + productId));
    }

    @Transactional(readOnly = true)
    public List<InventoryDto> getLowStock(int threshold) {
        return inventoryRepository.findLowStock(threshold).stream()
                .map(this::toDto)
                .toList();
    }

    @Transactional
    public InventoryDto create(Long productId, int quantity) {
        if (inventoryRepository.findByProductId(productId).isPresent()) {
            throw new IllegalArgumentException("Inventory already exists for product: " + productId);
        }

        Inventory inv = Inventory.builder()
                .productId(productId)
                .quantity(quantity)
                .reserved(0)
                .build();
        inventoryRepository.save(inv);
        log.info("Inventory created productId={} qty={}", productId, quantity);
        return toDto(inv);
    }

    @Transactional
    public InventoryDto reserve(Long productId, int quantity) {
        chaosDelayService.delayIfEnabled("reserveStock");

        Inventory inv = inventoryRepository.findByProductIdWithLock(productId)
                .orElseThrow(() -> new NotFoundException("Inventory not found: " + productId));

        if (!inv.canReserve(quantity)) {
            throw new InsufficientStockException(productId, inv.availableQuantity(), quantity);
        }

        inv.reserve(quantity);
        inventoryRepository.save(inv);
        log.info("Stock reserved productId={} qty={} available={}", productId, quantity, inv.availableQuantity());
        return toDto(inv);
    }

    @Transactional
    public InventoryDto release(Long productId, int quantity) {
        Inventory inv = inventoryRepository.findByProductIdWithLock(productId)
                .orElseThrow(() -> new NotFoundException("Inventory not found: " + productId));

        inv.release(quantity);
        inventoryRepository.save(inv);
        log.info("Stock released productId={} qty={}", productId, quantity);
        return toDto(inv);
    }

    @Transactional
    public InventoryDto deduct(Long productId, int quantity) {
        Inventory inv = inventoryRepository.findByProductIdWithLock(productId)
                .orElseThrow(() -> new NotFoundException("Inventory not found: " + productId));

        inv.deduct(quantity);
        inventoryRepository.save(inv);
        log.info("Stock deducted productId={} qty={} available={}", productId, quantity, inv.availableQuantity());
        return toDto(inv);
    }

    @Transactional
    public InventoryDto addStock(Long productId, int quantity) {
        Inventory inv = inventoryRepository.findByProductIdWithLock(productId)
                .orElseThrow(() -> new NotFoundException("Inventory not found: " + productId));

        inv.setQuantity(inv.getQuantity() + quantity);
        inventoryRepository.save(inv);
        log.info("Stock added productId={} qty={} total={}", productId, quantity, inv.getQuantity());
        return toDto(inv);
    }

    private InventoryDto toDto(Inventory inv) {
        return InventoryDto.builder()
                .productId(inv.getProductId())
                .quantity(inv.getQuantity())
                .reserved(inv.getReserved())
                .availableQuantity(inv.availableQuantity())
                .updatedAt(inv.getUpdatedAt())
                .build();
    }
}
