package com.shopwave.inventory.dto;

import jakarta.validation.constraints.Positive;
import lombok.Data;

@Data
public class StockMutationRequest {
    @Positive
    private int quantity;
}
