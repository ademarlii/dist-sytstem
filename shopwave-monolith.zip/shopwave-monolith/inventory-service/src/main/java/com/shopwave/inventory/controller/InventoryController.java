package com.shopwave.inventory.controller;

import com.shopwave.inventory.dto.InventoryDto;
import com.shopwave.inventory.dto.StockMutationRequest;
import com.shopwave.inventory.service.InventoryService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/inventory")
@RequiredArgsConstructor
public class InventoryController {

    private final InventoryService inventoryService;

    @GetMapping("/products/{productId}")
    public InventoryDto getByProductId(@PathVariable Long productId) {
        return inventoryService.getByProductId(productId);
    }

    @GetMapping("/low-stock")
    public List<InventoryDto> lowStock(@RequestParam(defaultValue = "10") int threshold) {
        return inventoryService.getLowStock(threshold);
    }

    @PostMapping("/products/{productId}")
    @ResponseStatus(HttpStatus.CREATED)
    public InventoryDto create(@PathVariable Long productId,
                               @Valid @RequestBody StockMutationRequest req) {
        return inventoryService.create(productId, req.getQuantity());
    }

    @PostMapping("/products/{productId}/reserve")
    public InventoryDto reserve(@PathVariable Long productId,
                                @Valid @RequestBody StockMutationRequest req) {
        return inventoryService.reserve(productId, req.getQuantity());
    }

    @PostMapping("/products/{productId}/release")
    public InventoryDto release(@PathVariable Long productId,
                                @Valid @RequestBody StockMutationRequest req) {
        return inventoryService.release(productId, req.getQuantity());
    }

    @PostMapping("/products/{productId}/deduct")
    public InventoryDto deduct(@PathVariable Long productId,
                               @Valid @RequestBody StockMutationRequest req) {
        return inventoryService.deduct(productId, req.getQuantity());
    }

    @PostMapping("/products/{productId}/add")
    public InventoryDto addStock(@PathVariable Long productId,
                                 @Valid @RequestBody StockMutationRequest req) {
        return inventoryService.addStock(productId, req.getQuantity());
    }
}
