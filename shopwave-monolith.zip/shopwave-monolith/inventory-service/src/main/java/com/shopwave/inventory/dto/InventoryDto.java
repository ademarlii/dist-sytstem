package com.shopwave.inventory.dto;

import lombok.Builder;
import lombok.Data;

import java.time.OffsetDateTime;

@Data
@Builder
public class InventoryDto {
    private Long productId;
    private int quantity;
    private int reserved;
    private int availableQuantity;
    private OffsetDateTime updatedAt;
}
