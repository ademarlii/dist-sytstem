package com.shopwave.inventory.service;

import com.shopwave.inventory.config.ChaosDelayProperties;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.concurrent.ThreadLocalRandom;

@Slf4j
@Service
@RequiredArgsConstructor
public class ChaosDelayService {

    private final ChaosDelayProperties properties;

    public void delayIfEnabled(String operation) {
        if (!properties.isEnabled() || !properties.getTargetOperations().contains(operation)) {
            return;
        }

        long delayMs = calculateDelayMs();
        if (delayMs <= 0) {
            return;
        }

        log.warn("Chaos delay injected operation={} delayMs={}", operation, delayMs);
        sleep(delayMs);
    }

    private long calculateDelayMs() {
        long fixedMs = Math.max(0, properties.getFixedMs());
        long jitterMs = Math.max(0, properties.getJitterMs());
        if (jitterMs == 0) {
            return fixedMs;
        }
        return fixedMs + ThreadLocalRandom.current().nextLong(jitterMs + 1);
    }

    private void sleep(long delayMs) {
        try {
            Thread.sleep(delayMs);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("Chaos delay interrupted", e);
        }
    }
}
