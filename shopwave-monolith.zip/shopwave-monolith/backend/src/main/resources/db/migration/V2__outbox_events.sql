CREATE TABLE outbox_events (
    id           BIGSERIAL PRIMARY KEY,
    event_type   VARCHAR(80) NOT NULL,
    aggregate    VARCHAR(40),
    aggregate_id BIGINT,
    payload      TEXT,
    status       VARCHAR(20) NOT NULL DEFAULT 'PENDING',
    attempts     INT NOT NULL DEFAULT 0,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    processed_at TIMESTAMPTZ
);

CREATE INDEX idx_outbox_events_status_created
    ON outbox_events (status, created_at);
