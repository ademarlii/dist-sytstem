package com.shopwave.service;

import com.shopwave.dto.InventoryDto;
import com.shopwave.dto.StockMutationRequest;
import com.shopwave.exception.InsufficientStockException;
import com.shopwave.exception.NotFoundException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Service;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientResponseException;

import java.util.List;

/**
 * InventoryService - inventory-service HTTP adapter.
 *
 * Backend artik stok verisini kendi veritabanindan okumaz.
 * OrderService ve ProductService bu sinifi ayni local servis gibi kullanir,
 * fakat her cagri inventory-service'e HTTP istegine donusur.
 *
 * LAB NOTU (Servis Ayrimi - Lab 3):
 *   DB transaction siniri artik OrderService ile ortak degildir.
 *   Stok rezerve edildikten sonra order commit'i basarisiz olursa partial failure olusur.
 *   Sonraki lab'larda timeout, retry, idempotency ve saga ile ele alinacak.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class InventoryService {

    private final RestClient inventoryRestClient;

    @Value("${shopwave.inventory.retry.max-attempts}")
    private int maxAttempts;

    @Value("${shopwave.inventory.retry.backoff-ms}")
    private long backoffMs;

    // ─── Queries ──────────────────────────────────────────────

    public InventoryDto getByProductId(Long productId) {
        return call(() -> inventoryRestClient.get()
                .uri("/api/v1/inventory/products/{productId}", productId)
                .retrieve()
                .body(InventoryDto.class));
    }

    public List<InventoryDto> getLowStock(int threshold) {
        InventoryDto[] items = call(() -> inventoryRestClient.get()
                .uri("/api/v1/inventory/low-stock?threshold={threshold}", threshold)
                .retrieve()
                .body(InventoryDto[].class));
        return List.of(items != null ? items : new InventoryDto[0]);
    }

    // ─── Commands ─────────────────────────────────────────────

    /**
     * Sipariş için stok ayır.
     * Pessimistic lock ile eş zamanlı isteklerde race condition önlenir.
     *
     * LAB NOTU:
     *   Tek instance'ta bu yeterli. Birden fazla backend instance çalıştığında
     *   DB lock hâlâ işe yarar (DB-level lock). Ama inventory ayrı servise
     *   taşınırsa bu metot HTTP'ye dönüşür ve DB lock artık kullanılamaz.
     */
    public void create(Long productId, int quantity) {
        call(() -> inventoryRestClient.post()
                .uri("/api/v1/inventory/products/{productId}", productId)
                .body(new StockMutationRequest(quantity))
                .retrieve()
                .body(InventoryDto.class));
    }

    public void reserve(Long productId, int quantity) {
        InventoryDto inv = call(() -> inventoryRestClient.post()
                .uri("/api/v1/inventory/products/{productId}/reserve", productId)
                .body(new StockMutationRequest(quantity))
                .retrieve()
                .body(InventoryDto.class));
        log.info("Stock reserved remotely productId={} qty={} available={}",
                productId, quantity, inv != null ? inv.getAvailableQuantity() : null);
    }

    /** Sipariş iptalinde rezervasyonu geri bırak. */
    public void release(Long productId, int quantity) {
        call(() -> inventoryRestClient.post()
                .uri("/api/v1/inventory/products/{productId}/release", productId)
                .body(new StockMutationRequest(quantity))
                .retrieve()
                .body(InventoryDto.class));
        log.info("Stock released remotely productId={} qty={}", productId, quantity);
    }

    /** Sipariş tesliminde fiziksel stoktan düş. */
    public void deduct(Long productId, int quantity) {
        call(() -> inventoryRestClient.post()
                .uri("/api/v1/inventory/products/{productId}/deduct", productId)
                .body(new StockMutationRequest(quantity))
                .retrieve()
                .body(InventoryDto.class));
        log.info("Stock deducted remotely productId={} qty={}", productId, quantity);
    }

    /** Manuel stok ekle (yeni sevkiyat geldiğinde). */
    public void addStock(Long productId, int quantity) {
        call(() -> inventoryRestClient.post()
                .uri("/api/v1/inventory/products/{productId}/add", productId)
                .body(new StockMutationRequest(quantity))
                .retrieve()
                .body(InventoryDto.class));
        log.info("Stock added remotely productId={} qty={}", productId, quantity);
    }

    private <T> T call(InventoryCall<T> call) {
        int attempts = Math.max(1, maxAttempts);
        for (int attempt = 1; attempt <= attempts; attempt++) {
            try {
                return call.execute();
            } catch (RestClientResponseException ex) {
                if (!isRetryable(ex) || attempt == attempts) {
                    throw mapRemoteError(ex);
                }
                log.warn("Inventory request failed with status={}, retrying attempt={}/{}",
                        ex.getStatusCode().value(), attempt + 1, attempts);
                backoff();
            } catch (ResourceAccessException ex) {
                if (attempt == attempts) {
                    throw new IllegalStateException("Inventory service unavailable or timed out", ex);
                }
                log.warn("Inventory request timed out/unavailable, retrying attempt={}/{}",
                        attempt + 1, attempts);
                backoff();
            }
        }
        throw new IllegalStateException("Inventory request failed");
    }

    private boolean isRetryable(RestClientResponseException ex) {
        return ex.getStatusCode().is5xxServerError();
    }

    private void backoff() {
        if (backoffMs <= 0) {
            return;
        }
        try {
            Thread.sleep(backoffMs);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("Inventory retry interrupted", e);
        }
    }

    private RuntimeException mapRemoteError(RestClientResponseException ex) {
        HttpStatusCode status = ex.getStatusCode();
        String body = ex.getResponseBodyAsString();
        if (status.value() == 404) {
            return new NotFoundException(remoteMessage(body, "Inventory not found"));
        }
        if (status.value() == 409) {
            return new InsufficientStockException(remoteMessage(body, "Insufficient stock"));
        }
        if (status.is4xxClientError()) {
            return new IllegalArgumentException(remoteMessage(body, "Inventory request failed"));
        }
        return new IllegalStateException(remoteMessage(body, "Inventory service failed"), ex);
    }

    private String remoteMessage(String body, String fallback) {
        return body == null || body.isBlank() ? fallback : body;
    }

    @FunctionalInterface
    private interface InventoryCall<T> {
        T execute();
    }
}
