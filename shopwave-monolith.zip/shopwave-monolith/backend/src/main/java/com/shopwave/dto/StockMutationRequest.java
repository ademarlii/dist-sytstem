package com.shopwave.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class StockMutationRequest {
    private int quantity;
}
