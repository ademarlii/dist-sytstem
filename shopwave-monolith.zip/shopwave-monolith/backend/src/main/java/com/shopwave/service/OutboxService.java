package com.shopwave.service;

import com.shopwave.domain.OutboxEvent;
import com.shopwave.repository.OutboxEventRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service
@RequiredArgsConstructor
public class OutboxService {

    private final OutboxEventRepository outboxEventRepository;

    @Transactional
    public void publish(String eventType, String aggregate, Long aggregateId, String payload) {
        save(eventType, aggregate, aggregateId, payload);
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void publishCompensation(String eventType, String aggregate, Long aggregateId, String payload) {
        save(eventType, aggregate, aggregateId, payload);
    }

    private void save(String eventType, String aggregate, Long aggregateId, String payload) {
        OutboxEvent event = OutboxEvent.builder()
                .eventType(eventType)
                .aggregate(aggregate)
                .aggregateId(aggregateId)
                .payload(payload)
                .build();
        outboxEventRepository.save(event);
        log.info("Outbox event saved type={} aggregate={} aggregateId={}", eventType, aggregate, aggregateId);
    }
}
