package com.shopwave.dto;

import lombok.Data;

import java.time.OffsetDateTime;

@Data
public class InventoryDto {
    private Long productId;
    private int quantity;
    private int reserved;
    private int availableQuantity;
    private OffsetDateTime updatedAt;
}
